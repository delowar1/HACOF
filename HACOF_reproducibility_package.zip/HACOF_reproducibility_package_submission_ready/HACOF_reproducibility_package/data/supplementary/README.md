# Author-supplied supplementary load-sweep dataset

This file was supplied after the main reproducibility package was assembled. It contains
15 records (three observations at each of 200, 400, 600, 800, and 1000 target TPS) with
`DispersionOrgs=15` and `ConflictModel=MVCC-30`. Because it is not the same schema or run
count as the 30-run pairwise MVCC completion-latency and 15-organisation endorsement
comparison datasets used for the manuscript's primary statistical claims, it is retained as
supplementary provenance and is not silently substituted for those canonical datasets.
