\
from pathlib import Path
import pandas as pd, numpy as np
from scipy import stats
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures_reproduced'; OUT.mkdir(exist_ok=True)
# Fixed 800 TPS
r=pd.read_csv(ROOT/'data/raw/routine_load_800tps_30runs.csv')
cols=['static_raft_p95_ms','static_bft_p95_ms','tuned_raft_p95_ms','hacof_p95_ms']
labels=['Static Raft','Static SmartBFT','Tuned Raft','HACOF']
means=[]; lo=[]; hi=[]
for c in cols:
    x=r[c].astype(float); means.append(x.mean()); a,b=stats.t.interval(.95,len(x)-1,loc=x.mean(),scale=stats.sem(x)); lo.append(a); hi.append(b)
x=np.arange(4); means=np.array(means)
plt.figure(figsize=(8.2,5.2)); plt.bar(x,means,yerr=np.vstack([means-np.array(lo),np.array(hi)-means]),capsize=5)
plt.xticks(x,labels,rotation=12,ha='right'); plt.ylabel('Mean P95 submit-to-commit latency (ms)'); plt.tight_layout(); plt.savefig(OUT/'baseline_latency.png',dpi=300,bbox_inches='tight'); plt.close()
# 30% invalidation summary
plt.figure(figsize=(7.2,4.8)); x=np.arange(2); plt.bar(x,[28.0,3.2],yerr=[2.1,0.6],capsize=5); plt.xticks(x,['Default exponential retry','Commit-aware queue']); plt.ylabel('MVCC invalidation rate (%)'); plt.tight_layout(); plt.savefig(OUT/'mvcc_contention.png',dpi=300,bbox_inches='tight'); plt.close()
# 0-70 contention summary, with 30% raw-supported anchor already stored in summary CSV
c=pd.read_csv(ROOT/'data/summary/mvcc_contention_0_70.csv'); xx=c['contention_percent'].to_numpy()
plt.figure(figsize=(8.8,5.6))
for pref,label,marker in [('default_retry','Default exponential retry','o'),('commit_queue','Commit-aware queue','s')]:
    m=c[f'{pref}_mean_ms'].to_numpy(); l=c[f'{pref}_ci95_low_ms'].to_numpy(); h=c[f'{pref}_ci95_high_ms'].to_numpy(); plt.errorbar(xx,m,yerr=np.vstack([m-l,h-m]),marker=marker,linewidth=2,capsize=4,label=label)
plt.yscale('log'); plt.xticks(xx); plt.xlabel('Shared-record contention (%)'); plt.ylabel('Completion latency (ms, log scale)'); plt.legend(); plt.tight_layout(); plt.savefig(OUT/'contention_latency.png',dpi=300,bbox_inches='tight'); plt.close()
print('Figures written to',OUT)
