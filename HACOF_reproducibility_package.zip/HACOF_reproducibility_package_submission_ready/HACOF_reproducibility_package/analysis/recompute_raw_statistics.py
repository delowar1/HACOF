\
from pathlib import Path
import pandas as pd
from scipy import stats
ROOT=Path(__file__).resolve().parents[1]
for rel in ['data/raw/routine_load_800tps_30runs.csv','data/raw/consortium_scaling_15org_30runs.csv','data/raw/mvcc_30pct_run_values.csv']:
    df=pd.read_csv(ROOT/rel)
    print('\n'+rel)
    for c in df.columns[1:]:
        x=df[c].astype(float)
        lo,hi=stats.t.interval(0.95,len(x)-1,loc=x.mean(),scale=stats.sem(x))
        print(f'{c}: n={len(x)}, mean={x.mean():.4f}, SD={x.std(ddof=1):.4f}, t95=[{lo:.4f},{hi:.4f}]')
