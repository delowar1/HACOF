// DERIVED scaffold only.
module.exports.createWorkloadModule = require('./UpdateClinicalRecordEmergency').createWorkloadModule;
