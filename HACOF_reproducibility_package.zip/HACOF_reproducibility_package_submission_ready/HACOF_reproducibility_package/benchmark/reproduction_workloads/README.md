# Reproduction workload provenance

These modules implement the transaction classes/scenarios documented in the manuscript and benchmark YAML.
They are provided for reproduction; where the exact historical byte-identical JavaScript module was not retained,
the file is a reconstruction from the supplied benchmark specification. The manuscript states this explicitly.
