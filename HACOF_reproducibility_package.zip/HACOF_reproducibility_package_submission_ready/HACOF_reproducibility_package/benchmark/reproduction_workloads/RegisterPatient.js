'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class Workload extends WorkloadModuleBase {
  constructor() {
    super();
    this.txIndex = 0;
  }

  async submitTransaction() {
    this.txIndex++;
    const request = {
      contractId: 'healthcare',
      contractFunction: 'RegisterPatient',
      contractArguments: [`patient_${this.txIndex}`, `namehash_${this.txIndex}`, "1990-01-01"],
      readOnly: false
    };
    return this.sutAdapter.sendRequests(request);
  }
}

module.exports.createWorkloadModule = () => new Workload();
