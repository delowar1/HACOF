'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class Workload extends WorkloadModuleBase {
  constructor() {
    super();
    this.txIndex = 0;
  }

  async submitTransaction() {
    this.txIndex++;
    const request = {
      contractId: 'healthcare',
      contractFunction: 'LogNonEmergencyAudit',
      contractArguments: [`audit_${this.txIndex}`, "actor", "ACCESS", `target_${this.txIndex}`, "1699999999"],
      readOnly: false
    };
    return this.sutAdapter.sendRequests(request);
  }
}

module.exports.createWorkloadModule = () => new Workload();
