// DERIVED scaffold only.
module.exports.createWorkloadModule = require('./UpdateClinicalRecordRoutine').createWorkloadModule;
