'use strict';
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class Workload extends WorkloadModuleBase {
  constructor() {
    super();
    this.txIndex = 0;
  }

  async submitTransaction() {
    this.txIndex++;
    const request = {
      contractId: 'healthcare',
      contractFunction: 'SubmitLabResult',
      contractArguments: [`lab_${this.txIndex}`, `patient_${this.txIndex % 1000}`, "TEST", "result-hash", "1699999999"],
      readOnly: false
    };
    return this.sutAdapter.sendRequests(request);
  }
}

module.exports.createWorkloadModule = () => new Workload();
