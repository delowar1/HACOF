# Release metadata

Release type: anonymous peer-review supplementary artefact
Public repository: not asserted for peer review
Archival DOI: not asserted for peer review
Fabric version: 3.0.0
Manuscript title: Risk- and Urgency-Aware Policy Routing for Adaptive Transaction Assurance in Hyperledger Fabric Healthcare IoT Networks
