package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type SmartContract struct {
	contractapi.Contract
}

type ClinicalRecord struct {
	RecordID     string `json:"recordID"`
	PatientID    string `json:"patientID"`
	DataHash     string `json:"dataHash"`
	Urgency      string `json:"urgency"` // "routine" or "emergency"
	ConsentToken string `json:"consentToken"`
	Timestamp    int64  `json:"timestamp"`
	AuthorOrg    string `json:"authorOrg"`
}

type PatientRegistration struct {
	PatientID    string `json:"patientID"`
	NameHash     string `json:"nameHash"`
	DOB          string `json:"dob"`
	RegisteredBy string `json:"registeredBy"`
	Timestamp    int64  `json:"timestamp"`
}

type LabResult struct {
	LabID      string `json:"labID"`
	PatientID  string `json:"patientID"`
	TestCode   string `json:"testCode"`
	ResultHash string `json:"resultHash"`
	Timestamp  int64  `json:"timestamp"`
}

type PharmacyPrescription struct {
	RxID      string `json:"rxID"`
	PatientID string `json:"patientID"`
	DrugCode  string `json:"drugCode"`
	Status    string `json:"status"`
	Timestamp int64  `json:"timestamp"`
}

type ClaimRecord struct {
	ClaimID   string `json:"claimID"`
	PatientID string `json:"patientID"`
	Amount    int64  `json:"amount"`
	Status    string `json:"status"`
	Timestamp int64  `json:"timestamp"`
}

type AuditLogEntry struct {
	AuditID   string `json:"auditID"`
	Actor     string `json:"actor"`
	Action    string `json:"action"`
	TargetID  string `json:"targetID"`
	Timestamp int64  `json:"timestamp"`
}

func (s *SmartContract) RegisterPatient(ctx contractapi.TransactionContextInterface, patientID, nameHash, dob string) error {
	exists, err := s.AssetExists(ctx, patientID)
	if err != nil {
		return fmt.Errorf("failed reading world state: %v", err)
	}
	if exists {
		return fmt.Errorf("patient %s already registered", patientID)
	}

	clientID, err := ctx.ClientIdentity.GetMSPID()
	if err != nil {
		return fmt.Errorf("failed getting client msp id: %v", err)
	}

	reg := PatientRegistration{
		PatientID:    patientID,
		NameHash:     nameHash,
		DOB:          dob,
		RegisteredBy: clientID,
		Timestamp:    1699999999,
	}

	bytes, err := json.Marshal(reg)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("PATIENT_"+patientID, bytes)
}

func (s *SmartContract) UpdateClinicalRecord(ctx contractapi.TransactionContextInterface, recordID, patientID, dataHash, urgency, consentToken string, timestamp int64) error {
	clientID, err := ctx.ClientIdentity.GetMSPID()
	if err != nil {
		return fmt.Errorf("failed getting client msp id: %v", err)
	}

	record := ClinicalRecord{
		RecordID:     recordID,
		PatientID:    patientID,
		DataHash:     dataHash,
		Urgency:      urgency,
		ConsentToken: consentToken,
		Timestamp:    timestamp,
		AuthorOrg:    clientID,
	}

	bytes, err := json.Marshal(record)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("REC_"+recordID, bytes)
}

func (s *SmartContract) SubmitLabResult(ctx contractapi.TransactionContextInterface, labID, patientID, testCode, resultHash string, timestamp int64) error {
	lab := LabResult{
		LabID:      labID,
		PatientID:  patientID,
		TestCode:   testCode,
		ResultHash: resultHash,
		Timestamp:  timestamp,
	}
	bytes, err := json.Marshal(lab)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("LAB_"+labID, bytes)
}

func (s *SmartContract) FulfillPharmacy(ctx contractapi.TransactionContextInterface, rxID, patientID, drugCode, status string, timestamp int64) error {
	rx := PharmacyPrescription{
		RxID:      rxID,
		PatientID: patientID,
		DrugCode:  drugCode,
		Status:    status,
		Timestamp: timestamp,
	}
	bytes, err := json.Marshal(rx)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("RX_"+rxID, bytes)
}

func (s *SmartContract) ProcessClaim(ctx contractapi.TransactionContextInterface, claimID, patientID string, amount int64, status string, timestamp int64) error {
	claim := ClaimRecord{
		ClaimID:   claimID,
		PatientID: patientID,
		Amount:    amount,
		Status:    status,
		Timestamp: timestamp,
	}
	bytes, err := json.Marshal(claim)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("CLAIM_"+claimID, bytes)
}

func (s *SmartContract) LogNonEmergencyAudit(ctx contractapi.TransactionContextInterface, auditID, actor, action, targetID string, timestamp int64) error {
	audit := AuditLogEntry{
		AuditID:   auditID,
		Actor:     actor,
		Action:    action,
		TargetID:  targetID,
		Timestamp: timestamp,
	}
	bytes, err := json.Marshal(audit)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("AUDIT_"+auditID, bytes)
}

func (s *SmartContract) AssetExists(ctx contractapi.TransactionContextInterface, assetID string) (bool, error) {
	bytes, err := ctx.GetStub().GetState("PATIENT_" + assetID)
	if err != nil {
		return false, err
	}
	return bytes != nil, nil
}

func main() {
	cc, err := contractapi.NewChaincode(&SmartContract{})
	if err != nil {
		panic(fmt.Sprintf("Error creating healthcare chaincode: %v", err))
	}
	if err := cc.Start(); err != nil {
		panic(fmt.Sprintf("Error starting healthcare chaincode: %v", err))
	}
}
