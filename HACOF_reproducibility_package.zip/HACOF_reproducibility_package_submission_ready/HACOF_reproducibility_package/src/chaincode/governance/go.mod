module hacof/chaincode-governance

go 1.21

require github.com/hyperledger/fabric-contract-api-go v1.2.2
