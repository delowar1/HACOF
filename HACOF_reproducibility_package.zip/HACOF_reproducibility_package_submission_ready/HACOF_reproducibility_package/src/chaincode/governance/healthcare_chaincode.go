package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type HealthcareContract struct {
	contractapi.Contract
}

type ConsentRecord struct {
	PatientID    string   `json:"patient_id"`
	Version      int      `json:"version"`
	AllowedOrgs  []string `json:"allowed_orgs"`
	IsRevoked    bool     `json:"is_revoked"`
	LastModified string   `json:"last_modified"`
}

type AuditEvent struct {
	EventID   string `json:"event_id"`
	ActorID   string `json:"actor_id"`
	Action    string `json:"action"`
	Timestamp string `json:"timestamp"`
	Hash      string `json:"hash"`
}

// UpdateConsent records or revokes patient consent on the governance SmartBFT channel.
func (c *HealthcareContract) UpdateConsent(ctx contractapi.TransactionContextInterface, patientID string, version int, allowedOrgsJSON string, isRevoked bool) error {
	var orgs []string
	if err := json.Unmarshal([]byte(allowedOrgsJSON), &orgs); err != nil {
		return fmt.Errorf("failed to unmarshal allowed orgs: %v", err)
	}

	record := ConsentRecord{
		PatientID:    patientID,
		Version:      version,
		AllowedOrgs:  orgs,
		IsRevoked:    isRevoked,
		LastModified: ctx.GetStub().GetTxID(),
	}

	data, err := json.Marshal(record)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(fmt.Sprintf("CONSENT~%s", patientID), data)
}

// VerifyConsent evaluates current authoritative consent state.
func (c *HealthcareContract) VerifyConsent(ctx contractapi.TransactionContextInterface, patientID string, requestingOrg string) (bool, int, error) {
	data, err := ctx.GetStub().GetState(fmt.Sprintf("CONSENT~%s", patientID))
	if err != nil || data == nil {
		return false, 0, fmt.Errorf("consent record not found for patient: %s", patientID)
	}

	var record ConsentRecord
	if err := json.Unmarshal(data, &record); err != nil {
		return false, 0, err
	}

	if record.IsRevoked {
		return false, record.Version, nil
	}

	for _, org := range record.AllowedOrgs {
		if org == requestingOrg {
			return true, record.Version, nil
		}
	}

	return false, record.Version, nil
}

// RecordAudit commits security and emergency access-decision audit events.
func (c *HealthcareContract) RecordAudit(ctx contractapi.TransactionContextInterface, eventID string, actorID string, action string, timestamp string, hash string) error {
	event := AuditEvent{
		EventID:   eventID,
		ActorID:   actorID,
		Action:    action,
		Timestamp: timestamp,
		Hash:      hash,
	}
	data, err := json.Marshal(event)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(fmt.Sprintf("AUDIT~%s", eventID), data)
}

func main() {
	cc, err := contractapi.NewChaincode(&HealthcareContract{})
	if err != nil {
		panic(fmt.Sprintf("Error creating healthcare chaincode: %v", err))
	}
	if err := cc.Start(); err != nil {
		panic(fmt.Sprintf("Error starting healthcare chaincode: %v", err))
	}
}
