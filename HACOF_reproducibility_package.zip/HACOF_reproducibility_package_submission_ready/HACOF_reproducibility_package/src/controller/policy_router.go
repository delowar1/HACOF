package main

import (
	"sync"
	"time"

	bolt "go.etcd.io/bbolt"
)

// RequestContext contains already-authenticated attributes emitted by Algorithm 1.
type RequestContext struct {
	RequestID           string    `json:"request_id"`
	OperationType       string    `json:"operation_type"` // read, consent_change, policy_change, clinical_update, audit, telemetry
	Urgency             string    `json:"urgency"`        // routine, urgent, emergency
	Sensitivity         string    `json:"sensitivity"`    // low, medium, high
	CrossOrg            bool      `json:"cross_org"`
	GovernedStateChange bool      `json:"governed_state_change"`
	TargetKey           string    `json:"target_key"`
	AdmittedAt          time.Time `json:"admitted_at"`
}

// RoutingDecision is the deterministic assurance class returned by Algorithm 2.
type RoutingDecision struct {
	Class            string `json:"class"`       // R0, W0 ... W4
	Path             string `json:"path"`        // evaluate or submit
	Channel          string `json:"channel"`     // operational-raft or governance-smartbft
	QueueClass       string `json:"queue_class"` // RO, Q0 ... Q4
	EndorsementClass string `json:"endorsement_class"`
	CommitAware      bool   `json:"commit_aware"`
}

type HACOFController struct {
	db          *bolt.DB
	mu          sync.Mutex
	activeLocks map[string]bool
}

func NewHACOFController(dbPath string) (*HACOFController, error) {
	db, err := bolt.Open(dbPath, 0600, &bolt.Options{Timeout: time.Second})
	if err != nil {
		return nil, err
	}
	if err := db.Update(func(tx *bolt.Tx) error {
		_, err := tx.CreateBucketIfNotExists([]byte("CommitAwareQueue"))
		return err
	}); err != nil {
		_ = db.Close()
		return nil, err
	}
	return &HACOFController{db: db, activeLocks: map[string]bool{}}, nil
}

func (c *HACOFController) Close() error { return c.db.Close() }

// ClassifyAndRoute implements the manuscript branch order exactly:
// R0 read; W4 non-urgent governance audit; W0 urgent governed write;
// W1 other governed write; W2 sensitive operational write; W3 routine operational write.
func (c *HACOFController) ClassifyAndRoute(ctx RequestContext) RoutingDecision {
	if ctx.OperationType == "read" {
		return RoutingDecision{Class: "R0", Path: "evaluate", Channel: "governance-smartbft", QueueClass: "RO", EndorsementClass: "n/a"}
	}

	if ctx.OperationType == "audit" && ctx.Urgency == "routine" {
		return RoutingDecision{Class: "W4", Path: "submit", Channel: "governance-smartbft", QueueClass: "Q4", EndorsementClass: "governance-audit"}
	}

	governed := ctx.GovernedStateChange || ctx.OperationType == "consent_change" || ctx.OperationType == "policy_change"
	if governed {
		if ctx.Urgency == "urgent" || ctx.Urgency == "emergency" {
			return RoutingDecision{Class: "W0", Path: "submit", Channel: "governance-smartbft", QueueClass: "Q0", EndorsementClass: "SBE-strong", CommitAware: true}
		}
		return RoutingDecision{Class: "W1", Path: "submit", Channel: "governance-smartbft", QueueClass: "Q1", EndorsementClass: "SBE-strong", CommitAware: true}
	}

	if ctx.Sensitivity == "high" || ctx.Sensitivity == "medium" {
		return RoutingDecision{Class: "W2", Path: "submit", Channel: "operational-raft", QueueClass: "Q2", EndorsementClass: "SBE-policy"}
	}

	return RoutingDecision{Class: "W3", Path: "submit", Channel: "operational-raft", QueueClass: "Q3", EndorsementClass: "SBE-default"}
}

// AcquireCommitLock serialises selected protected-key updates and persists the pending key.
func (c *HACOFController) AcquireCommitLock(key string) error {
	for {
		c.mu.Lock()
		if !c.activeLocks[key] {
			c.activeLocks[key] = true
			c.mu.Unlock()
			break
		}
		c.mu.Unlock()
		time.Sleep(5 * time.Millisecond)
	}
	return c.db.Update(func(tx *bolt.Tx) error {
		return tx.Bucket([]byte("CommitAwareQueue")).Put([]byte(key), []byte("pending"))
	})
}

// ReleaseCommitLock is called after commit or a terminal failure.
func (c *HACOFController) ReleaseCommitLock(key string) error {
	c.mu.Lock()
	delete(c.activeLocks, key)
	c.mu.Unlock()
	return c.db.Update(func(tx *bolt.Tx) error {
		return tx.Bucket([]byte("CommitAwareQueue")).Delete([]byte(key))
	})
}
