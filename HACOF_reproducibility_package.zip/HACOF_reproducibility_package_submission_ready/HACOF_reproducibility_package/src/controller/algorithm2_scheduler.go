package main

import (
	"container/heap"
	"fmt"
	"sync"
	"time"
)

// TransactionRequest is the application-level state-changing request queued by HACOF.
type TransactionRequest struct {
	TxID       string
	QueueClass string
	Priority   float64
	AdmittedAt time.Time
	Index      int
}

type PriorityQueue []*TransactionRequest

func (pq PriorityQueue) Len() int { return len(pq) }
func (pq PriorityQueue) Less(i, j int) bool {
	if pq[i].Priority == pq[j].Priority {
		return pq[i].AdmittedAt.Before(pq[j].AdmittedAt)
	}
	return pq[i].Priority > pq[j].Priority
}
func (pq PriorityQueue) Swap(i, j int) { pq[i], pq[j] = pq[j], pq[i]; pq[i].Index = i; pq[j].Index = j }
func (pq *PriorityQueue) Push(x any) {
	item := x.(*TransactionRequest)
	item.Index = len(*pq)
	*pq = append(*pq, item)
}
func (pq *PriorityQueue) Pop() any {
	old := *pq
	n := len(old)
	item := old[n-1]
	old[n-1] = nil
	item.Index = -1
	*pq = old[:n-1]
	return item
}

type TokenBucket struct {
	capacity, tokens, refillRate float64
	last                         time.Time
	mu                           sync.Mutex
}

func NewTokenBucket(capacity, refillRate float64) *TokenBucket {
	return &TokenBucket{capacity: capacity, tokens: capacity, refillRate: refillRate, last: time.Now()}
}
func (b *TokenBucket) Allow() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	now := time.Now()
	b.tokens += now.Sub(b.last).Seconds() * b.refillRate
	b.last = now
	if b.tokens > b.capacity {
		b.tokens = b.capacity
	}
	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

type Scheduler struct {
	mu     sync.Mutex
	queues map[string]*PriorityQueue
	q0     *TokenBucket
	delta  time.Duration
}

func NewScheduler() *Scheduler {
	s := &Scheduler{queues: map[string]*PriorityQueue{}, q0: NewTokenBucket(50, 10), delta: 100 * time.Millisecond}
	for _, q := range []string{"Q0", "Q1", "Q2", "Q3", "Q4"} {
		pq := PriorityQueue{}
		heap.Init(&pq)
		s.queues[q] = &pq
	}
	go s.age()
	return s
}
func (s *Scheduler) Enqueue(tx *TransactionRequest) error {
	if _, ok := s.queues[tx.QueueClass]; !ok {
		return fmt.Errorf("unknown queue %s", tx.QueueClass)
	}
	if tx.QueueClass == "Q0" && !s.q0.Allow() {
		return fmt.Errorf("Q0 token bucket exhausted")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	heap.Push(s.queues[tx.QueueClass], tx)
	return nil
}
func (s *Scheduler) age() {
	t := time.NewTicker(s.delta)
	defer t.Stop()
	for now := range t.C {
		s.mu.Lock()
		for _, q := range []string{"Q2", "Q3", "Q4"} {
			for _, tx := range *s.queues[q] {
				tx.Priority += now.Sub(tx.AdmittedAt).Seconds() * 0.05
			}
			heap.Init(s.queues[q])
		}
		s.mu.Unlock()
	}
}
func (s *Scheduler) Pop(queue string) (*TransactionRequest, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	pq, ok := s.queues[queue]
	if !ok || pq.Len() == 0 {
		return nil, false
	}
	return heap.Pop(pq).(*TransactionRequest), true
}
