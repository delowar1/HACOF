module hacof/controller

go 1.21

require go.etcd.io/bbolt v1.3.8
