# HACOF controller implementation

- `policy_router.go` implements the manuscript branch order for R0 and W0-W4, including the non-urgent audit W4/Q4 branch, plus persistent per-key commit locks.
- `algorithm2_scheduler.go` is the submission application-level implementation of the author-supplied Algorithm 2 priority-queue/token-bucket logic: Q0 capacity 50, refill 10 tokens/s, 100 ms ageing interval, and ageing for Q2-Q4.

The original Algorithm 2 source supplied by the authors is retained verbatim under `provenance/author_supplied_algorithm2.go`.
