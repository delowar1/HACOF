/*
 * SPDX-License-Identifier: Apache-2.0
 * HACOF Framework - Algorithm 2 Implementation
 * Component: State-Changing Transaction Controller & Priority Queue Rate Limiter
 */

package main

import (
	"container/heap"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	pb "github.com/hyperledger/fabric-protos-go/peer"
)

// TransactionRequest represents an incoming state-changing transaction.
type TransactionRequest struct {
	TxID      string    `json:"txId"`
	Sender    string    `json:"sender"`
	Payload   string    `json:"payload"`
	Priority  float64   `json:"priority"`
	Timestamp time.Time `json:"timestamp"`
	Index     int       `json:"index"` // Needed for heap interface
}

// PriorityQueue implements heap.Interface and holds TransactionRequests.
type PriorityQueue []*TransactionRequest

func (pq PriorityQueue) Len() int { return len(pq) }

func (pq PriorityQueue) Less(i, j int) bool {
	// Higher priority value comes first; tie-breaker by earlier timestamp
	if pq[i].Priority == pq[j].Priority {
		return pq[i].Timestamp.Before(pq[j].Timestamp)
	}
	return pq[i].Priority > pq[j].Priority
}

func (pq PriorityQueue) Swap(i, j int) {
	pq[i], pq[j] = pq[j], pq[i]
	pq[i].Index = i
	pq[j].Index = j
}

func (pq *PriorityQueue) Push(x interface{}) {
	n := len(*pq)
	item := x.(*TransactionRequest)
	item.Index = n
	*pq = append(*pq, item)
}

func (pq *PriorityQueue) Pop() interface{} {
	old := *pq
	n := len(old)
	item := old[n-1]
	old[n-1] = nil  // avoid memory leak
	item.Index = -1 // for safety
	*pq = old[0 : n-1]
	return item
}

// TokenBucket implements the rate-limiting mechanism for Algorithm 2.
type TokenBucket struct {
	capacity     float64
	tokens       float64
	refillRate   float64 // tokens per second
	lastRefilled time.Time
	mu           sync.Mutex
}

func NewTokenBucket(capacity, refillRate float64) *TokenBucket {
	return &TokenBucket{
		capacity:     capacity,
		tokens:       capacity,
		refillRate:   refillRate,
		lastRefilled: time.Now(),
	}
}

func (tb *TokenBucket) Allow() bool {
	tb.mu.Lock()
	defer tb.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(tb.lastRefilled).Seconds()
	tb.lastRefilled = now

	// Refill tokens based on elapsed time
	tb.tokens += elapsed * tb.refillRate
	if tb.tokens > tb.capacity {
		tb.tokens = tb.capacity
	}

	if tb.tokens >= 1.0 {
		tb.tokens -= 1.0
		return true
	}
	return false
}

// HACOFController implements Algorithm 2: Rate-limited priority queue and state-changing coordinator.
type HACOFController struct {
	tokenBucket *TokenBucket
	pq          PriorityQueue
	mu          sync.Mutex
	deltaQ      time.Duration // Priority recomputation interval (e.g., 100ms)
}

func NewHACOFController(capacity, refillRate float64, deltaQ time.Duration) *HACOFController {
	controller := &HACOFController{
		tokenBucket: NewTokenBucket(capacity, refillRate),
		pq:          make(PriorityQueue, 0),
		deltaQ:      deltaQ,
	}
	heap.Init(&controller.pq)

	// Start background priority recomputation worker (Interval: Delta Q)
	go controller.startPriorityRecomputationWorker()

	return controller
}

// EnqueueTransaction processes incoming state-changing requests according to Algorithm 2.
func (c *HACOFController) EnqueueTransaction(tx *TransactionRequest) error {
	// Step 1: Token Bucket Rate Limiting check
	if !c.tokenBucket.Allow() {
		return fmt.Errorf("rate limit exceeded: transaction %s dropped or throttled", tx.TxID)
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	// Step 2: Push into Priority Queue
	heap.Push(&c.pq, tx)
	return nil
}

// startPriorityRecomputationWorker periodically updates priorities based on waiting time and attributes ($\Delta_q$).
func (c *HACOFController) startPriorityRecomputationWorker() {
	ticker := time.NewTicker(c.deltaQ)
	for range ticker.C {
		c.mu.Lock()
		if c.pq.Len() > 0 {
			now := time.Now()
			for _, tx := range c.pq {
				// Dynamic aging factor to prevent starvation
				waitingDuration := now.Sub(tx.Timestamp).Seconds()
				tx.Priority += waitingDuration * 0.05
			}
			heap.Init(&c.pq) // Re-heapify after priority updates
		}
		c.mu.Unlock()
	}
}

// PopNextBatch retrieves the top-priority batch of transactions for ordered submission.
func (c *HACOFController) PopNextBatch(batchSize int) []*TransactionRequest {
	c.mu.Lock()
	defer c.mu.Unlock()

	var batch []*TransactionRequest
	for i := 0; i < batchSize && c.pq.Len() > 0; i++ {
		tx := heap.Pop(&c.pq).(*TransactionRequest)
		batch = append(batch, tx)
	}
	return batch
}

// Algorithm2SmartContract implements the Hyperledger Fabric Chaincode interface for Algorithm 2.
type Algorithm2SmartContract struct {
	controller *HACOFController
}

func (s *Algorithm2SmartContract) Init(stub shim.ChaincodeStubInterface) pb.Response {
	// Initialize controller with C = 50 capacity, 10 tokens/s refill, Delta_q = 100ms
	s.controller = NewHACOFController(50.0, 10.0, 100*time.Millisecond)
	return shim.Success([]byte("HACOF Algorithm 2 Controller Initialized Successfully"))
}

func (s *Algorithm2SmartContract) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	fn, args := stub.GetFunctionAndParameters()

	switch fn {
	case "SubmitStateChangingTx":
		if len(args) < 3 {
			return shim.Error("Incorrect number of arguments. Expecting [TxID, Sender, Payload]")
		}
		tx := &TransactionRequest{
			TxID:      args[0],
			Sender:    args[1],
			Payload:   args[2],
			Priority:  10.0, // Initial base priority
			Timestamp: time.Now(),
		}

		err := s.controller.EnqueueTransaction(tx)
		if err != nil {
			return shim.Error(err.Error())
		}

		txBytes, _ := json.Marshal(tx)
		return shim.Success(txBytes)

	case "ProcessBatch":
		batch := s.controller.PopNextBatch(10)
		batchBytes, _ := json.Marshal(batch)
		return shim.Success(batchBytes)

	default:
		return shim.Error(fmt.Sprintf("Invalid transaction function name: %s", fn))
	}
}

func main() {
	err := shim.Start(new(Algorithm2SmartContract))
	if err != nil {
		fmt.Printf("Error starting Algorithm 2 chaincode: %s\n", err)
	}
}
