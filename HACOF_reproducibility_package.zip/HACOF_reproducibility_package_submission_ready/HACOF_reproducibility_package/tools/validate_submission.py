\
from pathlib import Path
import csv, hashlib, re, sys, yaml, subprocess
import pandas as pd
from scipy import stats
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=['paper/manuscript.tex','paper/manuscript.pdf','paper/MANUSCRIPT_SHA256.txt','network/configtx.yaml','data/DATA_COVERAGE.csv','data/CLAIMS_REGISTRY.csv','src/controller/policy_router.go','src/controller/algorithm2_scheduler.go','src/chaincode/governance/healthcare_chaincode.go','src/chaincode/operational/healthcare_cc.go','healthcare_data_environment/synthea/generate_synthea.sh','fault_injection/inject_crash.sh']
for p in required:
    if not (ROOT/p).exists(): errors.append('missing '+p)
router=(ROOT/'src/controller/policy_router.go').read_text()
for token in ['Class: "R0"','Class: "W0"','Class: "W1"','Class: "W2"','Class: "W3"','Class: "W4"','QueueClass: "Q4"']:
    if token not in router: errors.append('controller route token missing '+token)
tex=(ROOT/'paper/manuscript.tex').read_text()
for bad in ['AUTHOR CHECK','[REPOSITORY URL]','[DOI]','F(4,116)','Tukey HSD-adjusted','AbsoluteMaxBytes=99 MB','$650 \\pm 25$','extunderscore']:
    if bad in tex: errors.append('stale/unsupported manuscript token: '+bad)
# YAML structure
try: cfg=yaml.safe_load((ROOT/'network/configtx.yaml').read_text())
except Exception as e: errors.append('configtx YAML parse failure: '+str(e)); cfg={}
if cfg:
    if cfg.get('Capabilities',{}).get('Channel',{}).get('V3_0') is not True: errors.append('Channel V3_0 missing')
    profiles=cfg.get('Profiles',{})
    raft=profiles.get('OperationalRaftChannel',{}).get('Orderer',{}).get('EtcdRaft',{}).get('Consenters',[])
    bft=profiles.get('GovernanceSmartBFTChannel',{}).get('Orderer',{}).get('ConsenterMapping',[])
    if len(raft)!=3: errors.append(f'expected 3 Raft consenters, got {len(raft)}')
    if len(bft)!=4: errors.append(f'expected 4 BFT consenters, got {len(bft)}')
    # ensure six distinct org policy principals
    orgs=cfg.get('Organizations',[])
    if len(orgs)!=6: errors.append(f'expected 6 organisations, got {len(orgs)}')
    for o in orgs:
        msp=o.get('ID',''); rule=str(o.get('Policies',{}).get('Readers',{}).get('Rule',''))
        if msp and msp not in rule: errors.append(f'policy principal mismatch for {o.get("Name")}')
# raw stats values in manuscript
checks=[
 ('data/raw/routine_load_800tps_30runs.csv','hacof_p95_ms',210.5,210.2,210.7),
 ('data/raw/consortium_scaling_15org_30runs.csv','hacof_selective_tps',650.9,647.7,654.0),
 ('data/raw/consortium_scaling_15org_30runs.csv','and_endorsement_tps',178.9,177.3,180.5),
 ('data/raw/mvcc_30pct_run_values.csv','default_retry_completion_ms',3403.3,3375.4,3431.2),
 ('data/raw/mvcc_30pct_run_values.csv','commit_aware_queue_completion_ms',680.0,676.9,683.1),
]
for rel,col,mexp,loexp,hiexp in checks:
    x=pd.read_csv(ROOT/rel)[col].astype(float); lo,hi=stats.t.interval(.95,len(x)-1,loc=x.mean(),scale=stats.sem(x))
    if round(x.mean(),1)!=mexp or round(lo,1)!=loexp or round(hi,1)!=hiexp: errors.append(f'stat mismatch {rel}:{col}')
# Evidence coverage must include all key families.
coverage={r['experiment']:r for r in csv.DictReader((ROOT/'data/DATA_COVERAGE.csv').open())}
for name in ['Emergency component latency','Controlled ablation','Shared-record contention at 30%','15-organisation scalability','Maximum sustainable TPS sweep']:
    if name not in coverage: errors.append('coverage missing '+name)
# Exact checksum for embedded manuscript
expected=(ROOT/'paper/MANUSCRIPT_SHA256.txt').read_text().strip().split()[0]
actual=hashlib.sha256((ROOT/'paper/manuscript.pdf').read_bytes()).hexdigest()
if expected!=actual: errors.append('manuscript PDF hash mismatch')
# Verify all listed package checksums when the final manifest is present.
manifest=ROOT/'SHA256SUMS.txt'
if manifest.exists():
    for line in manifest.read_text().splitlines():
        if not line.strip(): continue
        h,rel=line.split('  ',1)
        fp=ROOT/rel
        if not fp.exists(): errors.append('checksum manifest missing file '+rel); continue
        if hashlib.sha256(fp.read_bytes()).hexdigest()!=h: errors.append('checksum mismatch '+rel)
if errors:
    print('VALIDATION FAILED')
    for e in errors: print('-',e)
    sys.exit(1)
print('VALIDATION PASSED: manuscript, evidence registry, Fabric config, and raw-supported statistics are aligned.')
