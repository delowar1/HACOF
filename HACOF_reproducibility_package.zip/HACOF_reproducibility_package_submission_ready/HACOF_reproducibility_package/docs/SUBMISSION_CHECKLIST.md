# Submission checklist

- [x] Manuscript PDF and LaTeX source identical to the manuscript source package.
- [x] All four manuscript figures included in the source package and reproducibility package.
- [x] Architecture figure present (no LaTeX placeholder box).
- [x] Fabric v3 Channel capability V3_0 present.
- [x] Three Raft and four SmartBFT consenters represented.
- [x] Organisation-specific policy principals; no cross-organisation YAML policy alias reuse.
- [x] Operational AbsoluteMaxBytes normalised to 49 MB in the released reproduction configuration.
- [x] Algorithm 2 priority/token-bucket implementation present with original author input preserved.
- [x] 800-TPS, 15-org, and 30%-contention raw statistics directly recomputable.
- [x] 15-org dispersion reported as run-level 95% CI, not unexplained +/- values.
- [x] 30%-contention completion-latency intervals recomputed from retained raw vectors.
- [x] Unsupported ablation ANOVA/post-hoc claim removed.
- [x] Emergency/crash/consent/controller/Byzantine/congestion evidence explicitly labelled summary-only where applicable.
- [x] No AUTHOR CHECK, repository URL, DOI, or licence placeholder tokens in manuscript.
- [x] No stale blocking checklist included.
- [x] SHA256 manifest regenerated only after final package assembly.
