# Automated submission validation

```text
VALIDATION PASSED: manuscript, evidence registry, Fabric config, and raw-supported statistics are aligned.
```
