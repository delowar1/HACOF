# Statistical evidence policy

For the three canonical 30-run datasets (fixed 800 TPS, 15-organisation throughput,
and 30% contention completion latency), the package recomputes the arithmetic mean,
sample SD, and two-sided Student-t 95% confidence interval using each complete run as
the experimental unit.

Historical experiments for which only aggregate exports are retained are marked
`summary only` in `data/DATA_COVERAGE.csv`. Their reported intervals are preserved as
reported summaries; no synthetic run vectors are generated and no new inferential tests
are claimed. In particular, the component ablation is descriptive in the submission manuscript.
