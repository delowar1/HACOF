# HACOF submission reproducibility runbook

## 1. Validate package and manuscript alignment
```bash
python -m pip install -r analysis/requirements.txt
make validate
make stats
make figures
make sources
```

## 2. Fabric configuration
`network/configtx.yaml` is the reviewer-facing Fabric v3.0 reproduction configuration.
It contains six organisations, a three-consenter Raft operational profile, a four-consenter
BFT governance profile, and Channel capability V3_0. MSP/TLS private material is intentionally
not distributed; generate test identities and update the illustrative certificate paths.

## 3. Healthcare data environment
Use `healthcare_data_environment/synthea/generate_synthea.sh`, then start the HAPI-FHIR /
PostgreSQL and Redis Compose stacks. Use `cache_manager.sh` to reset or warm the cache.

## 4. Controller and chaincode
Controller code is under `src/controller/`; governance and operational chaincode are under
`src/chaincode/`. The source validator runs `gofmt` syntax checks.

## 5. Data and figures
`data/DATA_COVERAGE.csv` is authoritative for evidence level. Raw-supported manuscript
statistics can be recomputed using `analysis/recompute_raw_statistics.py`; summary-only
conditions are not converted into synthetic raw data.
