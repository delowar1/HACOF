# Provenance

The submission package was assembled from the author-supplied HACOF artefacts and the
supplementary document provided on 15 August 2026. The supplementary document is retained
verbatim under `provenance/supplementary.docx`.

The primary manuscript statistical claims use the existing canonical 30-run CSVs for the
fixed 800 TPS, 15-organisation endorsement comparison, and 30% contention completion-latency
experiments. The later supplementary 15-organisation/MVCC-30 target-load CSV is retained as
auxiliary provenance because it has a different schema and contains 15 records rather than the
canonical 30-run pairwise vectors; it is not silently substituted into the primary claims.

The application-level Algorithm 2 scheduler in `src/controller/algorithm2_scheduler.go` adapts
the author-supplied queue/token-bucket code to the manuscript's gateway-controller placement.
The original supplied source is retained unchanged in `provenance/author_supplied_algorithm2.go`.

The supplementary document also contained an updated author-provided `configtx.yaml` excerpt.
It is extracted under `provenance/author_supplied_configtx_supplementary.yaml`. The reviewer-facing
`network/configtx.yaml` is the manuscript-aligned six-organisation reproduction configuration; it
is intentionally kept separate from the author-supplied excerpt so that provenance and submission
configuration are not conflated.
