#!/usr/bin/env bash
set -euo pipefail

java -jar synthea-with-dependencies.jar -p 10000 --exporter.fhir.export=true --exporter.base_directory=./output/fhir
