#!/usr/bin/env bash
set -e

REDIS_HOST=${REDIS_HOST:-"localhost"}
REDIS_PORT=${REDIS_PORT:-"6379"}

echo "Executing cold-cache reset..."
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" FLUSHALL
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" CONFIG SET maxmemory-policy allkeys-lru

echo "Preparing warm-cache benchmark baseline..."
for i in {1..5000}; do
  redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" SET "patient:cache:$i" "{\"id\":\"$i\",\"status\":\"active\",\"consent\":true}"
done
echo "Cache initialization and warming completed successfully."
