#!/bin/bash
set -euo pipefail

TARGET_NODE="smartbft-orderer4"

echo "=== Injecting network partition / message withholding on ${TARGET_NODE} ==="
docker exec -it ${TARGET_NODE} tc qdisc add dev eth0 root netem delay 500ms loss 25% corrupt 5%

echo "=== Maintaining Byzantine impairment for 120s ==="
sleep 120

echo "=== Restoring network conditions on ${TARGET_NODE} ==="
docker exec -it ${TARGET_NODE} tc qdisc del dev eth0 root
echo "=== Fault injection test completed successfully ==="
