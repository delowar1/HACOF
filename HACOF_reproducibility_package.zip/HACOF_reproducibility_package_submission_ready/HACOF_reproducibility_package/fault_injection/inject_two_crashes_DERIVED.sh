\
#!/usr/bin/env bash
set -euo pipefail

# DERIVED REPRODUCTION HELPER, not claimed to be the original executed script.
# It implements the manuscript's stated "two simultaneous node failures" condition
# by killing both targets before either is restarted.

TARGET1="${1:-smartbft-orderer1}"
TARGET2="${2:-smartbft-orderer2}"
WINDOW="${3:-60}"

echo "=== Killing ${TARGET1} and ${TARGET2} before recovery ==="
docker kill --signal=SIGKILL "${TARGET1}"
docker kill --signal=SIGKILL "${TARGET2}"

echo "=== Holding two-node outage for ${WINDOW}s ==="
sleep "${WINDOW}"

echo "=== Restarting targets ==="
docker start "${TARGET1}"
docker start "${TARGET2}"
