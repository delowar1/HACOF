# Fault injection

`inject_crash.sh` and `inject_byzantine_partition.sh` are retained author-supplied scripts.
`inject_two_crashes_DERIVED.sh` is a clearly labelled helper implementing the manuscript's
simultaneous two-crash timing and is not presented as byte-identical historical source.
