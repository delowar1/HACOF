#!/bin/bash
set -euo pipefail

TARGET_CONTAINER="${1:-smartbft-orderer1}"

echo "=== Killing container ${TARGET_CONTAINER} to simulate crash fault ==="
docker kill --signal=SIGKILL ${TARGET_CONTAINER}

echo "=== Waiting 60s measurement window ==="
sleep 60

echo "=== Restarting container ${TARGET_CONTAINER} ==="
docker start ${TARGET_CONTAINER}
