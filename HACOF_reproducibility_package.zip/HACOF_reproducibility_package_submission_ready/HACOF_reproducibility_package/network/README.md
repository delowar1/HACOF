# Fabric v3 reproduction configuration

`configtx.yaml` is the submission reproduction configuration aligned to the manuscript.
It uses Channel capability `V3_0`, three Raft consenters for the operational channel,
and four BFT consenters for the governance channel. Organisation policy principals are
specified separately for each organisation. `AbsoluteMaxBytes` is set to 49 MB in the
released reproduction configuration; this stays within the default-gRPC guidance in the
Hyperledger Fabric performance documentation and is far above the 512 KB preferred block target.

The package intentionally does not distribute MSP private keys. Replace the illustrative
certificate paths with generated test credentials before invoking `configtxgen`.
